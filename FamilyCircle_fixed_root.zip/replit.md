# Family Chat Application

## Overview

This is a full-stack family chat application built with React, Node.js, Express, and PostgreSQL. The application provides real-time messaging capabilities for family members with features like multiple chat rooms, file uploads, message reactions, and typing indicators. It uses Replit's authentication system for user management and WebSockets for real-time communication.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend, backend, and database layers:

- **Frontend**: React with TypeScript, built with Vite
- **Backend**: Node.js with Express and TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Real-time Communication**: WebSockets for live messaging
- **Authentication**: Replit Auth with session management
- **UI Framework**: shadcn/ui components with Tailwind CSS

## Key Components

### Frontend Architecture
- **React with TypeScript**: Main frontend framework
- **Vite**: Build tool and development server
- **Wouter**: Lightweight client-side routing
- **TanStack Query**: Server state management and caching
- **shadcn/ui**: Pre-built UI components with Radix UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom family chat theme

### Backend Architecture
- **Express.js**: Web application framework
- **TypeScript**: Type-safe JavaScript
- **Drizzle ORM**: Type-safe database operations
- **WebSocket Server**: Real-time bidirectional communication
- **Multer**: File upload handling
- **Session Management**: PostgreSQL-backed sessions

### Database Schema
- **Users**: User profiles with Replit Auth integration
- **Chat Rooms**: Multiple themed family chat rooms
- **Messages**: Text messages with file attachments
- **Room Members**: Many-to-many relationship between users and rooms
- **Message Reactions**: Emoji reactions on messages
- **Sessions**: Session storage for authentication

### Authentication & Authorization
- **Replit OpenID Connect**: OAuth-based authentication
- **Session-based Auth**: Server-side session management
- **Protected Routes**: Middleware for API route protection
- **User Context**: React context for authentication state

## Data Flow

1. **User Authentication**: 
   - Users authenticate via Replit OAuth
   - Sessions stored in PostgreSQL
   - User profiles created/updated on login

2. **Real-time Messaging**:
   - WebSocket connection established on authentication
   - Messages broadcast to room members
   - Typing indicators and reactions sent in real-time

3. **File Uploads**:
   - Files uploaded to local storage via Multer
   - File metadata stored in message records
   - Files served statically from uploads directory

4. **Room Management**:
   - Default rooms created automatically
   - Users can join multiple rooms
   - Room-specific message history and members

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL connection pooling
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **express-session**: Session middleware
- **connect-pg-simple**: PostgreSQL session store
- **ws**: WebSocket implementation
- **multer**: File upload middleware

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling
- **date-fns**: Date formatting utilities
- **lucide-react**: Icon library

### Development Dependencies
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **vite**: Frontend build tool and dev server

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

### Development Mode
- Uses `tsx` to run TypeScript directly
- Vite dev server for frontend with HMR
- WebSocket server integrated with Express
- PostgreSQL database provisioned automatically

### Production Build
- Frontend built with Vite to `dist/public`
- Backend bundled with esbuild to `dist/index.js`
- Static file serving for built frontend
- Environment-based configuration

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `REPL_ID`: Replit environment identifier
- `ISSUER_URL`: OAuth provider URL

## Changelog

```
Changelog:
- June 27, 2025. Initial setup
- June 27, 2025. Fixed user room membership - users now automatically join all family rooms on login
- June 27, 2025. Application ready for family sharing - multiple family members can now access and use the chat
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```