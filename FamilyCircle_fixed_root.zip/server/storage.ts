import {
  users,
  chatRooms,
  messages,
  roomMembers,
  messageReactions,
  type User,
  type UpsertUser,
  type ChatRoom,
  type InsertChatRoom,
  type Message,
  type InsertMessage,
  type RoomMember,
  type InsertRoomMember,
  type MessageReaction,
  type InsertMessageReaction,
  type MessageWithSender,
  type ChatRoomWithMembers,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Chat room operations
  getChatRooms(userId: string): Promise<ChatRoomWithMembers[]>;
  createChatRoom(room: InsertChatRoom): Promise<ChatRoom>;
  getChatRoom(id: number): Promise<ChatRoom | undefined>;
  
  // Message operations
  getMessages(roomId: number, limit?: number, offset?: number): Promise<MessageWithSender[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Room member operations
  addRoomMember(roomMember: InsertRoomMember): Promise<RoomMember>;
  getRoomMembers(roomId: number): Promise<User[]>;
  isRoomMember(userId: string, roomId: number): Promise<boolean>;
  
  // Reaction operations
  addReaction(reaction: InsertMessageReaction): Promise<MessageReaction>;
  removeReaction(messageId: number, userId: string, emoji: string): Promise<void>;
  
  // Initialize default rooms
  initializeDefaultRooms(): Promise<void>;
  
  // Add user to all default rooms
  addUserToDefaultRooms(userId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getChatRooms(userId: string): Promise<ChatRoomWithMembers[]> {
    const userRooms = await db
      .select({
        room: chatRooms,
        members: sql<User[]>`
          COALESCE(
            (
              SELECT json_agg(
                json_build_object(
                  'id', u.id,
                  'email', u.email,
                  'firstName', u.first_name,
                  'lastName', u.last_name,
                  'profileImageUrl', u.profile_image_url,
                  'createdAt', u.created_at,
                  'updatedAt', u.updated_at
                )
              )
              FROM room_members rm
              JOIN users u ON rm.user_id = u.id
              WHERE rm.room_id = ${chatRooms.id}
            ),
            '[]'::json
          )
        `,
      })
      .from(chatRooms)
      .innerJoin(roomMembers, eq(roomMembers.roomId, chatRooms.id))
      .where(eq(roomMembers.userId, userId))
      .orderBy(desc(chatRooms.updatedAt));

    return userRooms.map(({ room, members }) => ({
      ...room,
      members,
    }));
  }

  async createChatRoom(roomData: InsertChatRoom): Promise<ChatRoom> {
    const [room] = await db
      .insert(chatRooms)
      .values(roomData)
      .returning();
    return room;
  }

  async getChatRoom(id: number): Promise<ChatRoom | undefined> {
    const [room] = await db.select().from(chatRooms).where(eq(chatRooms.id, id));
    return room;
  }

  async getMessages(roomId: number, limit = 50, offset = 0): Promise<MessageWithSender[]> {
    const messagesWithSender = await db
      .select({
        message: messages,
        sender: users,
        reactions: sql<MessageReaction[]>`
          COALESCE(
            (
              SELECT json_agg(
                json_build_object(
                  'id', mr.id,
                  'messageId', mr.message_id,
                  'userId', mr.user_id,
                  'emoji', mr.emoji,
                  'createdAt', mr.created_at
                )
              )
              FROM message_reactions mr
              WHERE mr.message_id = ${messages.id}
            ),
            '[]'::json
          )
        `,
      })
      .from(messages)
      .innerJoin(users, eq(messages.senderId, users.id))
      .where(eq(messages.roomId, roomId))
      .orderBy(desc(messages.createdAt))
      .limit(limit)
      .offset(offset);

    return messagesWithSender.map(({ message, sender, reactions }) => ({
      ...message,
      sender,
      reactions,
    }));
  }

  async createMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(messageData)
      .returning();
    return message;
  }

  async addRoomMember(roomMemberData: InsertRoomMember): Promise<RoomMember> {
    const [roomMember] = await db
      .insert(roomMembers)
      .values(roomMemberData)
      .returning();
    return roomMember;
  }

  async getRoomMembers(roomId: number): Promise<User[]> {
    const members = await db
      .select({ user: users })
      .from(roomMembers)
      .innerJoin(users, eq(roomMembers.userId, users.id))
      .where(eq(roomMembers.roomId, roomId));

    return members.map(({ user }) => user);
  }

  async isRoomMember(userId: string, roomId: number): Promise<boolean> {
    const [member] = await db
      .select()
      .from(roomMembers)
      .where(and(eq(roomMembers.userId, userId), eq(roomMembers.roomId, roomId)));
    return !!member;
  }

  async addReaction(reactionData: InsertMessageReaction): Promise<MessageReaction> {
    const [reaction] = await db
      .insert(messageReactions)
      .values(reactionData)
      .returning();
    return reaction;
  }

  async removeReaction(messageId: number, userId: string, emoji: string): Promise<void> {
    await db
      .delete(messageReactions)
      .where(
        and(
          eq(messageReactions.messageId, messageId),
          eq(messageReactions.userId, userId),
          eq(messageReactions.emoji, emoji)
        )
      );
  }

  async initializeDefaultRooms(): Promise<void> {
    const defaultRooms = [
      {
        name: "Main Family",
        description: "General family chat",
        icon: "home",
        color: "#4F46E5",
      },
      {
        name: "Kids Corner",
        description: "Just for the kids",
        icon: "child",
        color: "#10B981",
      },
      {
        name: "Family Planning",
        description: "Organize family events and activities",
        icon: "calendar-alt",
        color: "#F59E0B",
      },
      {
        name: "Photos & Memories",
        description: "Share family photos and memories",
        icon: "camera",
        color: "#8B5CF6",
      },
    ];

    for (const roomData of defaultRooms) {
      const existingRoom = await db
        .select()
        .from(chatRooms)
        .where(eq(chatRooms.name, roomData.name));

      if (existingRoom.length === 0) {
        await db.insert(chatRooms).values(roomData);
      }
    }
  }

  async addUserToDefaultRooms(userId: string): Promise<void> {
    // Get all default rooms
    const allRooms = await db.select().from(chatRooms);
    
    for (const room of allRooms) {
      // Check if user is already a member
      const isMember = await this.isRoomMember(userId, room.id);
      if (!isMember) {
        // Add user to the room
        await this.addRoomMember({ userId, roomId: room.id });
      }
    }
  }
}

export const storage = new DatabaseStorage();
