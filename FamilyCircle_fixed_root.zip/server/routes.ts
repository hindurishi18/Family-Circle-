import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertMessageSchema, insertMessageReactionSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    },
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// WebSocket connection management
interface WebSocketClient {
  ws: WebSocket;
  userId: string;
  roomId?: number;
}

const clients = new Map<string, WebSocketClient>();

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Initialize default chat rooms
  await storage.initializeDefaultRooms();

  // Serve uploaded files
  app.use("/uploads", express.static(uploadDir));

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Automatically add user to default rooms if they're not already in them
      await storage.addUserToDefaultRooms(userId);
      
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Chat room routes
  app.get('/api/rooms', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const rooms = await storage.getChatRooms(userId);
      res.json(rooms);
    } catch (error) {
      console.error("Error fetching rooms:", error);
      res.status(500).json({ message: "Failed to fetch rooms" });
    }
  });

  app.post('/api/rooms/:roomId/join', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roomId = parseInt(req.params.roomId);

      const isMember = await storage.isRoomMember(userId, roomId);
      if (!isMember) {
        await storage.addRoomMember({ userId, roomId });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Error joining room:", error);
      res.status(500).json({ message: "Failed to join room" });
    }
  });

  // Message routes
  app.get('/api/rooms/:roomId/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roomId = parseInt(req.params.roomId);
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;

      const isMember = await storage.isRoomMember(userId, roomId);
      if (!isMember) {
        return res.status(403).json({ message: "Not a member of this room" });
      }

      const messages = await storage.getMessages(roomId, limit, offset);
      res.json(messages.reverse()); // Reverse to show oldest first
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post('/api/rooms/:roomId/messages', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const roomId = parseInt(req.params.roomId);
      
      console.log(`Message send attempt - User: ${userId}, Room: ${roomId}, Body:`, req.body);
      
      const isMember = await storage.isRoomMember(userId, roomId);
      if (!isMember) {
        console.log(`User ${userId} is not a member of room ${roomId}`);
        return res.status(403).json({ message: "Not a member of this room" });
      }

      const messageData = insertMessageSchema.parse({
        ...req.body,
        senderId: userId,
        roomId,
      });

      const message = await storage.createMessage(messageData);
      console.log(`Message created successfully:`, message);
      
      // Get the full message with sender info
      const [fullMessage] = await storage.getMessages(roomId, 1, 0);
      
      // Broadcast to WebSocket clients
      broadcastToRoom(roomId, {
        type: 'new_message',
        message: fullMessage,
      });

      res.json(fullMessage);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Failed to create message", error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // File upload route
  app.post('/api/upload', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      console.log(`File upload attempt - User: ${req.user.claims.sub}`);
      
      if (!req.file) {
        console.log("No file in request");
        return res.status(400).json({ message: "No file uploaded" });
      }

      console.log(`File uploaded successfully:`, {
        originalName: req.file.originalname,
        filename: req.file.filename,
        size: req.file.size,
        mimetype: req.file.mimetype
      });

      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({
        url: fileUrl,
        name: req.file.originalname,
        type: req.file.mimetype,
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ message: "Failed to upload file", error: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Message reaction routes
  app.post('/api/messages/:messageId/reactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageId = parseInt(req.params.messageId);
      
      const reactionData = insertMessageReactionSchema.parse({
        ...req.body,
        messageId,
        userId,
      });

      const reaction = await storage.addReaction(reactionData);
      
      // Broadcast reaction to WebSocket clients
      broadcastToAll({
        type: 'reaction_added',
        reaction,
      });

      res.json(reaction);
    } catch (error) {
      console.error("Error adding reaction:", error);
      res.status(500).json({ message: "Failed to add reaction" });
    }
  });

  app.delete('/api/messages/:messageId/reactions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const messageId = parseInt(req.params.messageId);
      const { emoji } = req.body;

      await storage.removeReaction(messageId, userId, emoji);
      
      // Broadcast reaction removal to WebSocket clients
      broadcastToAll({
        type: 'reaction_removed',
        messageId,
        userId,
        emoji,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error removing reaction:", error);
      res.status(500).json({ message: "Failed to remove reaction" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket, req) => {
    const url = new URL(req.url!, `http://${req.headers.host}`);
    const userId = url.searchParams.get('userId');
    
    if (!userId) {
      ws.close(1008, 'User ID required');
      return;
    }

    const clientId = `${userId}-${Date.now()}`;
    clients.set(clientId, { ws, userId });

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'join_room') {
          const client = clients.get(clientId);
          if (client) {
            client.roomId = message.roomId;
          }
        }
        
        if (message.type === 'typing') {
          broadcastToRoom(message.roomId, {
            type: 'user_typing',
            userId,
            isTyping: message.isTyping,
          }, clientId);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      clients.delete(clientId);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(clientId);
    });
  });

  function broadcastToRoom(roomId: number, message: any, excludeClient?: string) {
    console.log(`Broadcasting to room ${roomId}:`, message);
    console.log(`Total clients: ${clients.size}`);
    
    clients.forEach((client, clientId) => {
      console.log(`Client ${clientId}: roomId=${client.roomId}, wsReady=${client.ws.readyState === WebSocket.OPEN}`);
      
      if (
        client.roomId === roomId &&
        client.ws.readyState === WebSocket.OPEN &&
        clientId !== excludeClient
      ) {
        console.log(`Sending message to client ${clientId}`);
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  function broadcastToAll(message: any) {
    console.log(`Broadcasting to all clients:`, message);
    clients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify(message));
      }
    });
  }

  return httpServer;
}
