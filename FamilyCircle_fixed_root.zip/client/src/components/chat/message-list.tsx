import { useEffect, useRef } from "react";
import { MessageWithSender } from "@shared/schema";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

interface MessageListProps {
  messages: MessageWithSender[];
  typingUsers: string[];
  roomId: number;
}

export default function MessageList({ messages, typingUsers }: MessageListProps) {
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  const formatTime = (date: Date | string) => {
    const messageDate = new Date(date);
    return messageDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const isOwnMessage = (senderId: string) => {
    return user?.id === senderId;
  };

  const getReactionCount = (reactions: any[], emoji: string) => {
    return reactions.filter(r => r.emoji === emoji).length;
  };

  const getUniqueReactions = (reactions: any[]) => {
    const reactionMap = new Map();
    reactions.forEach(reaction => {
      const key = reaction.emoji;
      if (reactionMap.has(key)) {
        reactionMap.set(key, reactionMap.get(key) + 1);
      } else {
        reactionMap.set(key, 1);
      }
    });
    return Array.from(reactionMap.entries());
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((message) => {
        const isOwn = isOwnMessage(message.senderId);
        const uniqueReactions = getUniqueReactions(message.reactions || []);
        
        return (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${isOwn ? 'flex-row-reverse space-x-reverse' : ''}`}
          >
            <Avatar className="w-8 h-8 flex-shrink-0">
              <AvatarImage src={message.sender?.profileImageUrl || ""} />
              <AvatarFallback>
                {getInitials(message.sender?.firstName, message.sender?.lastName)}
              </AvatarFallback>
            </Avatar>
            
            <div className={`flex-1 max-w-lg ${isOwn ? 'items-end' : ''}`}>
              <div className={`flex items-center space-x-2 mb-1 ${isOwn ? 'justify-end' : ''}`}>
                {!isOwn && (
                  <span className="text-sm font-medium text-gray-800">
                    {message.sender?.firstName || message.sender?.lastName 
                      ? `${message.sender?.firstName || ""} ${message.sender?.lastName || ""}`.trim()
                      : "Family Member"}
                  </span>
                )}
                <span className="text-xs text-gray-500">
                  {formatTime(message.createdAt!)}
                </span>
                {isOwn && <span className="text-sm font-medium text-gray-800">You</span>}
              </div>
              
              <div className={`rounded-lg px-4 py-2 shadow-sm ${
                isOwn 
                  ? 'bg-family-blue text-white ml-auto' 
                  : 'bg-white border border-gray-200'
              }`}>
                <p className={isOwn ? 'text-white' : 'text-gray-800'}>
                  {message.content}
                </p>
                
                {message.fileUrl && (
                  <div className="mt-2">
                    {message.fileType?.startsWith('image/') ? (
                      <img
                        src={message.fileUrl}
                        alt={message.fileName || "Shared image"}
                        className="rounded-lg max-w-full h-auto cursor-pointer hover:opacity-95 transition-opacity"
                        onClick={() => window.open(message.fileUrl, '_blank')}
                      />
                    ) : (
                      <div className="flex items-center space-x-2 p-2 bg-gray-100 rounded">
                        <span className="text-sm text-gray-600">📎</span>
                        <span className="text-sm text-gray-700">{message.fileName}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(message.fileUrl, '_blank')}
                        >
                          Download
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              {uniqueReactions.length > 0 && (
                <div className={`flex items-center space-x-2 mt-2 ${isOwn ? 'justify-end' : ''}`}>
                  {uniqueReactions.map(([emoji, count]) => (
                    <button
                      key={emoji}
                      className="flex items-center space-x-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-full px-2 py-1 transition-colors"
                    >
                      <span>{emoji}</span>
                      <span className="text-xs text-gray-600">{count}</span>
                    </button>
                  ))}
                  <button className="text-xs text-gray-400 hover:text-family-blue transition-colors">
                    Reply
                  </button>
                </div>
              )}
              
              {isOwn && (
                <div className={`flex items-center mt-2 ${isOwn ? 'justify-end' : ''}`}>
                  <span className="text-xs text-gray-500">✓✓ Read</span>
                </div>
              )}
            </div>
          </div>
        );
      })}
      
      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div className="flex items-start space-x-3">
          <Avatar className="w-8 h-8">
            <AvatarFallback>?</AvatarFallback>
          </Avatar>
          <div className="bg-white rounded-lg px-4 py-2 shadow-sm border border-gray-200">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
}
