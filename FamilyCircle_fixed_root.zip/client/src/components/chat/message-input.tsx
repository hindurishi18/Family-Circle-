import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Paperclip, Send, Smile } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface MessageInputProps {
  onSendMessage: (content: string, fileUrl?: string, fileName?: string, fileType?: string) => void;
  roomId: number;
}

export default function MessageInput({ onSendMessage, roomId }: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<{
    url: string;
    name: string;
    type: string;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  const handleSend = async () => {
    if (!message.trim() && !uploadedFile) return;

    try {
      await onSendMessage(
        message.trim(),
        uploadedFile?.url,
        uploadedFile?.name,
        uploadedFile?.type
      );
      setMessage("");
      setUploadedFile(null);
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await apiRequest('POST', '/api/upload', formData);
      const data = await response.json();
      
      setUploadedFile({
        url: data.url,
        name: data.name,
        type: data.type,
      });

      toast({
        title: "File uploaded",
        description: "Your file has been uploaded successfully",
      });
    } catch (error) {
      console.error("File upload error:", error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload file",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeFile = () => {
    setUploadedFile(null);
  };

  const adjustTextareaHeight = () => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  };

  return (
    <div className="bg-white border-t border-gray-200 p-4">
      <div className="flex items-end space-x-3">
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileUpload}
          className="hidden"
          accept="image/*,video/*,.pdf,.doc,.docx,.txt"
        />
        
        <Button
          variant="ghost"
          size="icon"
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
          className="flex-shrink-0 hover:bg-gray-100"
        >
          <Paperclip className="w-5 h-5 text-gray-500" />
        </Button>
        
        <div className="flex-1 relative">
          <Textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => {
              setMessage(e.target.value);
              adjustTextareaHeight();
            }}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            className="resize-none min-h-[44px] max-h-[120px] pr-12"
            rows={1}
          />
          
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 bottom-2 hover:bg-gray-100"
          >
            <Smile className="w-5 h-5 text-gray-500" />
          </Button>
        </div>
        
        <Button
          onClick={handleSend}
          disabled={!message.trim() && !uploadedFile}
          className="bg-family-blue hover:bg-blue-600 text-white flex-shrink-0"
        >
          <Send className="w-4 h-4 mr-2" />
          <span className="hidden sm:inline">Send</span>
        </Button>
      </div>
      
      {/* File upload preview */}
      {uploadedFile && (
        <div className="mt-3 p-3 bg-gray-50 rounded-lg flex items-center space-x-2">
          <span className="text-sm text-gray-700">📎 {uploadedFile.name}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={removeFile}
            className="ml-auto text-gray-500 hover:text-red-500"
          >
            ✕
          </Button>
        </div>
      )}
      
      {isUploading && (
        <div className="mt-3 p-3 bg-gray-50 rounded-lg flex items-center space-x-2">
          <div className="w-4 h-4 border-2 border-family-blue border-t-transparent rounded-full animate-spin"></div>
          <span className="text-sm text-gray-700">Uploading file...</span>
        </div>
      )}
    </div>
  );
}
