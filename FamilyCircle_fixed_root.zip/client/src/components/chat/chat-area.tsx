import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChatRoomWithMembers } from "@shared/schema";
import { useChat } from "@/hooks/useChat";
import { Button } from "@/components/ui/button";
import { Phone, Video, Info, Home, Users, Calendar, Camera, Baby } from "lucide-react";
import MessageList from "./message-list";
import MessageInput from "./message-input";

interface ChatAreaProps {
  room: ChatRoomWithMembers;
}

const roomIcons = {
  home: Home,
  child: Baby,
  "calendar-alt": Calendar,
  camera: Camera,
};

export default function ChatArea({ room }: ChatAreaProps) {
  const { joinRoom, sendMessage, messages, typingUsers } = useChat();

  const getIcon = (iconName: string) => {
    const IconComponent = roomIcons[iconName as keyof typeof roomIcons] || Home;
    return IconComponent;
  };

  const IconComponent = getIcon(room.icon || "home");

  useEffect(() => {
    if (room.id) {
      joinRoom(room.id);
    }
  }, [room.id, joinRoom]);

  const onlineCount = room.members.length; // Simplified - assume all members are online for now

  return (
    <div className="flex-1 flex flex-col">
      {/* Chat Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div 
              className="w-10 h-10 rounded-full flex items-center justify-center"
              style={{ 
                backgroundColor: `${room.color}20`,
              }}
            >
              <IconComponent style={{ color: room.color }} className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">{room.name}</h2>
              <p className="text-sm text-gray-500">
                {room.members.length} members • {onlineCount} online
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="hover:bg-gray-100">
              <Video className="w-5 h-5 text-gray-500" />
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-gray-100">
              <Phone className="w-5 h-5 text-gray-500" />
            </Button>
            <Button variant="ghost" size="icon" className="hover:bg-gray-100">
              <Info className="w-5 h-5 text-gray-500" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <MessageList 
        messages={messages} 
        typingUsers={typingUsers}
        roomId={room.id}
      />

      {/* Message Input */}
      <MessageInput 
        onSendMessage={sendMessage}
        roomId={room.id}
      />
    </div>
  );
}
