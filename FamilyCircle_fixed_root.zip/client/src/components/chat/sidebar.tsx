import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { ChatRoomWithMembers } from "@shared/schema";
import { Settings, Home, Users, Calendar, Camera, Baby } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface SidebarProps {
  selectedRoom: ChatRoomWithMembers | null;
  onRoomSelect: (room: ChatRoomWithMembers) => void;
}

const roomIcons = {
  home: Home,
  child: Baby,
  "calendar-alt": Calendar,
  camera: Camera,
};

export default function Sidebar({ selectedRoom, onRoomSelect }: SidebarProps) {
  const { user } = useAuth();
  
  const { data: rooms = [], isLoading } = useQuery<ChatRoomWithMembers[]>({
    queryKey: ["/api/rooms"],
  });

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  const getIcon = (iconName: string) => {
    const IconComponent = roomIcons[iconName as keyof typeof roomIcons] || Home;
    return IconComponent;
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return "U";
    return `${firstName?.charAt(0) || ""}${lastName?.charAt(0) || ""}`.toUpperCase();
  };

  if (isLoading) {
    return (
      <div className="w-80 bg-white border-r border-gray-200 flex items-center justify-center">
        <div className="text-center">
          <div className="w-6 h-6 border-2 border-family-blue border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold text-gray-800">Family Chat</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleLogout}
            className="hover:bg-gray-100"
          >
            <Settings className="w-5 h-5 text-gray-500" />
          </Button>
        </div>
        
        {/* User Profile */}
        <div className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors">
          <Avatar className="w-10 h-10 border-2 border-family-green">
            <AvatarImage src={user?.profileImageUrl || ""} alt={user?.firstName || "User"} />
            <AvatarFallback>{getInitials(user?.firstName, user?.lastName)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="font-medium text-gray-800">
              {user?.firstName || user?.lastName 
                ? `${user?.firstName || ""} ${user?.lastName || ""}`.trim()
                : "Family Member"}
            </p>
            <p className="text-sm text-gray-500">Online</p>
          </div>
          <div className="w-2 h-2 bg-family-green rounded-full"></div>
        </div>
      </div>

      {/* Chat Rooms */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-3">
          <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3">
            Family Rooms
          </h2>
          
          <div className="space-y-2">
            {rooms.map((room) => {
              const IconComponent = getIcon(room.icon || "home");
              const isSelected = selectedRoom?.id === room.id;
              
              return (
                <div
                  key={room.id}
                  onClick={() => onRoomSelect(room)}
                  className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-family-blue bg-opacity-5 border-l-2 border-family-blue"
                      : "hover:bg-family-blue hover:bg-opacity-10"
                  }`}
                >
                  <div className="flex-shrink-0">
                    <div 
                      className="w-12 h-12 rounded-full flex items-center justify-center"
                      style={{ 
                        backgroundColor: `${room.color}20`,
                      }}
                    >
                      <IconComponent style={{ color: room.color }} className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-gray-800 truncate">{room.name}</p>
                      <span className="text-xs text-gray-500">2:34 PM</span>
                    </div>
                    <p className="text-sm text-gray-600 truncate">
                      {room.description}
                    </p>
                  </div>
                  {room.unreadCount && room.unreadCount > 0 && (
                    <div className="flex-shrink-0">
                      <Badge variant="default" className="bg-family-blue">
                        {room.unreadCount}
                      </Badge>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Family Members */}
        <div className="p-3 border-t border-gray-200 mt-4">
          <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3">
            Family Members
          </h2>
          
          <div className="space-y-2">
            {rooms.flatMap(room => room.members).reduce((unique, member) => {
              return unique.find(u => u.id === member.id) ? unique : [...unique, member];
            }, [] as typeof rooms[0]['members']).map((member) => (
              <div
                key={member.id}
                className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded-lg cursor-pointer transition-colors"
              >
                <Avatar className="w-8 h-8">
                  <AvatarImage src={member.profileImageUrl || ""} alt={member.firstName || "Member"} />
                  <AvatarFallback>{getInitials(member.firstName, member.lastName)}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-800">
                    {member.firstName || member.lastName 
                      ? `${member.firstName || ""} ${member.lastName || ""}`.trim()
                      : "Family Member"}
                  </p>
                </div>
                <div className="w-2 h-2 bg-family-green rounded-full"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
