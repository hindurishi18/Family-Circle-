import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, MessageCircle, Shield, Users } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-family-bg to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-family-blue rounded-full flex items-center justify-center">
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
            Family Chat
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Stay connected with your loved ones through our warm, secure family chat platform.
            Share moments, plan together, and keep the family bond strong.
          </p>
          <Button
            onClick={handleLogin}
            size="lg"
            className="bg-family-blue hover:bg-blue-600 text-white px-8 py-4 text-lg rounded-lg"
          >
            Join Your Family Chat
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-family-green bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="w-6 h-6 text-family-green" />
              </div>
              <CardTitle>Real-time Chat</CardTitle>
              <CardDescription>
                Instant messaging with your family members. See when they're typing and get messages in real-time.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-family-amber bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-family-amber" />
              </div>
              <CardTitle>Family Rooms</CardTitle>
              <CardDescription>
                Organize conversations with dedicated rooms for different topics - family planning, photos, and more.
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-500 bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-purple-500" />
              </div>
              <CardTitle>Private & Secure</CardTitle>
              <CardDescription>
                Your family conversations are private and secure. Only invited family members can access your chats.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        <div className="text-center mt-16">
          <p className="text-gray-500 text-sm">
            Built with love for families who want to stay connected
          </p>
        </div>
      </div>
    </div>
  );
}
