import { useState, useEffect, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageWithSender } from "@shared/schema";
import { useAuth } from "./useAuth";
import { apiRequest } from "@/lib/queryClient";

export function useChat() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [currentRoomId, setCurrentRoomId] = useState<number | null>(null);
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Connect to WebSocket
  useEffect(() => {
    if (!user?.id) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws?userId=${user.id}`;
    
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'new_message':
          setMessages(prev => [...prev, data.message]);
          break;
        case 'user_typing':
          if (data.userId !== user.id) {
            setTypingUsers(prev => {
              if (data.isTyping) {
                return prev.includes(data.userId) ? prev : [...prev, data.userId];
              } else {
                return prev.filter(id => id !== data.userId);
              }
            });
          }
          break;
        case 'reaction_added':
          setMessages(prev => prev.map(msg => 
            msg.id === data.reaction.messageId 
              ? { ...msg, reactions: [...(msg.reactions || []), data.reaction] }
              : msg
          ));
          break;
        case 'reaction_removed':
          setMessages(prev => prev.map(msg => 
            msg.id === data.messageId 
              ? { 
                  ...msg, 
                  reactions: (msg.reactions || []).filter(r => 
                    !(r.userId === data.userId && r.emoji === data.emoji)
                  )
                }
              : msg
          ));
          break;
      }
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    return () => {
      ws.close();
    };
  }, [user?.id]);

  // Fetch messages for current room
  const { data: roomMessages = [] } = useQuery<MessageWithSender[]>({
    queryKey: ["/api/rooms", currentRoomId, "messages"],
    enabled: !!currentRoomId,
  });

  // Update messages when room messages change
  useEffect(() => {
    if (roomMessages.length > 0) {
      setMessages(roomMessages);
    }
  }, [roomMessages]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, fileUrl, fileName, fileType }: {
      content: string;
      fileUrl?: string;
      fileName?: string;
      fileType?: string;
    }) => {
      if (!currentRoomId) throw new Error("No room selected");
      
      const response = await apiRequest('POST', `/api/rooms/${currentRoomId}/messages`, {
        content,
        fileUrl,
        fileName,
        fileType,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rooms", currentRoomId, "messages"] });
    },
  });

  const joinRoom = useCallback((roomId: number) => {
    setCurrentRoomId(roomId);
    setMessages([]);
    setTypingUsers([]);
    
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'join_room',
        roomId,
      }));
    }
  }, []);

  const sendMessage = useCallback(async (
    content: string, 
    fileUrl?: string, 
    fileName?: string, 
    fileType?: string
  ) => {
    return sendMessageMutation.mutateAsync({ content, fileUrl, fileName, fileType });
  }, [sendMessageMutation]);

  const sendTyping = useCallback((isTyping: boolean) => {
    if (wsRef.current?.readyState === WebSocket.OPEN && currentRoomId) {
      wsRef.current.send(JSON.stringify({
        type: 'typing',
        roomId: currentRoomId,
        isTyping,
      }));
    }
  }, [currentRoomId]);

  // Handle typing indicator
  const handleTyping = useCallback(() => {
    sendTyping(true);
    
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    typingTimeoutRef.current = setTimeout(() => {
      sendTyping(false);
    }, 1000);
  }, [sendTyping]);

  return {
    messages,
    typingUsers,
    currentRoomId,
    joinRoom,
    sendMessage,
    handleTyping,
    isLoading: sendMessageMutation.isPending,
  };
}
